     /*======================================
        Show & Hide White Navigation 
        ===================================*/


		$(function () {
            $(window).scroll(function (){
 
 
         if ($(window).scrollTop() > 50) {
 
             // Show white nav
             $("header").addClass("top_bg");  
         }
         
         else {
 
             // Hide white nav
             $("header").removeClass("top_bg");
 
         }
     });
 });


/* =========================================
              Stats
============================================ */
$(function () {

    $(".counter").counterUp({
        delay: 10,
        time: 3000
    });

});
